#!/bin/sh

RETVAL=0
WGCLT="wgclt"
CHECKRUN="CheckRun"
WGSYNCDAEMON="wgsync"
prog="wgclt"

Wgclt=`ps -ef|grep -v "grep"|grep wgclt|awk '{print $2}'`
WgSync=`ps -ef|grep -v "grep"|grep wgsyncsrv|grep daemon|awk '{print $2}'`
CheckRun=`ps -ef|grep -v "grep"|grep CheckRun.sh|awk '{print $2}'`
warn=1

start()
{
	# Create keys if necessary
        Modinfo=`lsmod|grep dirpro|wc -l`
        if [ $Modinfo -lt $warn ]
	then
		insmod  ./dirpro.ko >/dev/null 2>&1
	else
		rmmod dirpro.ko
		insmod ./dirpro.ko
	fi
	echo -n $"Starting $prog:" 
	kill -9 $CheckRun >/dev/null 2>&1
	kill -9 $Wgclt >/dev/null 2>&1
	kill -9 $WgSync >/dev/null 2>&1
	rm -f wgsyncdaemon.pid
	rm -f wgclt.pid
	./wgsyncsrv --daemon --config=wgsync.conf
	./wgclt --daemon
	./CheckRun.sh &
	echo "Starting OK!"
}

stop()
{
	echo -n $"Stopping $prog:"
	kill -9 $CheckRun >/dev/null 2>&1
	kill -9 $Wgclt >/dev/null 2>&1
	kill -9 $WgSync >/dev/null 2>&1
	rm -f wgsyncdaemon.pid
	rm -f wgclt.pid
	sleep 3
        Modinfo=`lsmod|grep dirpro|wc -l`
        if [ $Modinfo -ge $warn ]
	then
		rmmod dirpro.ko
	fi
	echo "Stopped"
}

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	restart)
		stop
		start
		;;
	*)
		echo $"Usage: $0 {start|stop|restart}"
		RETVAL=1
esac
exit $RETVAL



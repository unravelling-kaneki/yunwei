#!/bin/sh

echo "Begin Install..."
echo "Kernel Ver $(uname -r)"
echo "Please Input Target Directory:"

read PROGRAMEDIR

if [ ! -d $PROGRAMEDIR ]; then
mkdir $PROGRAMEDIR 
fi

DIRPROKO=WGClt/dirpro-$(uname -r)-$(uname -m)-$(uname -p)-$(uname -i).ko

rm -rf $PROGRAMEDIR/WGClt
cp -R WGClt $PROGRAMEDIR/WGClt

rm -rf  $PROGRAMEDIR/WGClt/*.ko
if [ -f $DIRPROKO ]; then 
        cp -f $DIRPROKO $PROGRAMEDIR/WGClt/dirpro.ko
else
        echo "No Match Kernel Module\n"
fi



echo "Please Input Server IpAddress:"
read SERVERIP
echo "Please Input Server Port:"
read SERVERPORT
echo "Please Input Local IpAddress:"
read LOCALIP
configfile=$PROGRAMEDIR/WGClt/config/configfile.config
curpath=/etc/curpath

rm -f $configfile
touch $configfile

strconf="ServerName=$SERVERIP"
echo $strconf >> $configfile

strconf="ServerPort=$SERVERPORT"
echo $strconf >> $configfile

strconf="LocalName=$LOCALIP"
echo $strconf >> $configfile

strconf="LocalType=2"
echo $strconf >> $configfile

strconf="LocalPort=5367"
echo $strconf >> $configfile

strconf="TIMEOUT=5"
echo $strconf >> $configfile

echo "$PROGRAMEDIR/WGClt/CheckRun.sh &" >>/etc/rc.d/rc.local

cd $PROGRAMEDIR/WGClt/

echo $PROGRAMEDIR/WGClt/ >> $PROGRAMEDIR/WGClt/workpath.conf

rm -f $PROGRAMEDIR/WGClt/CheckRun.tmp
touch $PROGRAMEDIR/WGClt/CheckRun.tmp
echo "#!/bin/sh" >> $PROGRAMEDIR/WGClt/CheckRun.tmp
echo "APPDIR=$PROGRAMEDIR/WGClt/" >> $PROGRAMEDIR/WGClt/CheckRun.tmp
cat $PROGRAMEDIR/WGClt/CheckRun.sh >> $PROGRAMEDIR/WGClt/CheckRun.tmp
rm -f $PROGRAMEDIR/WGClt/CheckRun.sh
mv $PROGRAMEDIR/WGClt/CheckRun.tmp $PROGRAMEDIR/WGClt/CheckRun.sh
chmod 777 $PROGRAMEDIR/WGClt/CheckRun.sh

wgcltPath="/etc/wgclt/" 
fsconf="/etc/wgclt/fsconf.conf"

if [ ! -d $wgcltPath ]; then
mkdir $wgcltPath 
fi


if [ ! -f $fsconf ]; then
touch $fsconf 
fi

echo "/" >> $fsconf
echo "" >> $fsconf

echo "Installed!"

echo $PROGRAMEDIR/WGClt/ > $curpath

$PROGRAMEDIR/WGClt/CheckRun.sh &


